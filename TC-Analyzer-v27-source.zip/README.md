# TC Analyzer Android APK — v27

This Android WebView wrapper opens the live TC Analyzer system at https://tc-analyzer.hatchable.site/.

Version 27 includes the graduation-cap launcher branding, improved WebView configuration, file upload support, session cookies, external-link handling, and a GitHub Actions build workflow.

Important: marks, total points, merit, report-card calculations, and learner ranking are controlled by the live TC Analyzer web application. This APK wrapper does not replace that server-side logic.

## Build
Use GitHub Actions → Build TC Analyzer APK → Run workflow. The generated debug APK is uploaded as an artifact.
