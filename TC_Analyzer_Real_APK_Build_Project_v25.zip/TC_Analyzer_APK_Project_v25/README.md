# TC Analyzer Android APK — build project

This is a real Android WebView application wrapper for the live TC Analyzer system.
It opens https://tc-analyzer.hatchable.site/ and supports JavaScript, cookies and DOM storage for the sign-in/session flow.

## Build with Android Studio
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select `app` and choose Build > Build APK(s).
4. Install `app/build/outputs/apk/debug/app-debug.apk` on the Android phone.

## Build in GitHub Actions
Upload this project to a GitHub repository, then open Actions > Build TC Analyzer APK > Run workflow.
Download the generated `TC-Analyzer-debug-APK` artifact and install the APK on the phone.

The live website can change independently; the APK always opens the current live TC Analyzer URL.
