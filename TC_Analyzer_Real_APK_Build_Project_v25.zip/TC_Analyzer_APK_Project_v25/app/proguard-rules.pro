# TC Analyzer WebView wrapper: no custom shrinking rules required.
